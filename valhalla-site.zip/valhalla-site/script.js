// Nav shrink on scroll
  const nav = document.getElementById('siteNav');
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 60);
  });

  // Reveal on scroll
  const revealEls = document.querySelectorAll('.reveal');
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); }
    });
  }, {threshold:.15});
  revealEls.forEach(el => io.observe(el));

  // Lantern glow generator
  function scatterLanterns(containerId, count){
    const c = document.getElementById(containerId);
    if(!c) return;
    for(let i=0;i<count;i++){
      const dot = document.createElement('div');
      dot.className = 'lantern';
      dot.style.left = (Math.random()*96 + 2) + '%';
      dot.style.top = (Math.random()*70 + 8) + '%';
      dot.style.animationDelay = (Math.random()*3.6) + 's';
      c.appendChild(dot);
    }
  }
  scatterLanterns('heroLanterns', 24);
  scatterLanterns('reviewLanterns', 14);

  // Simple mobile menu toggle -> jump to enquire
  document.getElementById('menuBtn').addEventListener('click', () => {
    document.querySelector('#book').scrollIntoView({behavior:'smooth'});
  });

  function handleEnquiry(ev){
    ev.preventDefault();
    const note = document.getElementById('formNote');
    note.textContent = "Thanks — we've noted your enquiry. We'll call you shortly to confirm dates.";
    note.style.color = "var(--gold)";
    ev.target.reset();
    return false;
  }